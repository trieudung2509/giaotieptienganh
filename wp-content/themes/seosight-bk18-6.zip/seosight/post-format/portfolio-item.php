<?php
/**
 * Template part for portfolio grid items.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Seosight
 */
