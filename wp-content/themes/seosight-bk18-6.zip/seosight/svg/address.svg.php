<svg enable-background="new 0 0 64 64" version="1.1" viewBox="0 0 64 64" xml:space="preserve" xmlns="http://www.w3.org/2000/svg">
    <polygon fill="none"
             points="  38.7,36.4 56,32 38.7,27.6 42,22 36.4,25.3 32,8 27.6,25.3 22,22 25.3,27.6 8,32 25.3,36.4 22,42 27.6,38.7 32,56 36.4,38.7 42,42   "
             stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10"
             stroke-width="2" />
    <circle cx="32" cy="32" fill="none" r="4" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
            stroke-miterlimit="10" stroke-width="2"/>
    <path d="  M26.1,53.2c-7.9-2.2-13.9-8.6-15.6-16.7" fill="none" stroke="currentColor" stroke-linecap="round"
          stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"/>
    <path d="  M53.5,36.9c-1.8,8.1-8.2,14.6-16.3,16.5" fill="none" stroke="currentColor" stroke-linecap="round"
          stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"/>
    <path d="  M36.9,10.5c8.2,1.9,14.7,8.3,16.6,16.6" fill="none" stroke="currentColor" stroke-linecap="round"
          stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"/>
    <path d="  M10.5,27.1c1.9-8.2,8.3-14.6,16.4-16.5" fill="none" stroke="currentColor" stroke-linecap="round"
          stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"/>
</svg>