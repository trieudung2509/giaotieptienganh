<?php
/**
 * Register theme post types and taxonomies
 */

