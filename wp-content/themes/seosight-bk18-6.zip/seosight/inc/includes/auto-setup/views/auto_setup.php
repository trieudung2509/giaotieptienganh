<?php if ( ! defined( 'ABSPATH' ) ) {
	exit;
} ?>
<div class="wrap" data-unyson-nonce="<?php ?>">
	<p><?php esc_html_e('The update process is starting. This process may take a while on some hosts, so please be patient.', 'seosight'); ?></p>
</div>