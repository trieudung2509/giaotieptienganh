<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
$cfg = array();

$cfg['logo-url'] = get_template_directory_uri().'/images/logo.png';
$cfg['logo-item-url'] = 'https://s3.envato.com/files/237707650/thumbnail_80x80.png';

