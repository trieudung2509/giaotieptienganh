<?php

$manifest = array();

$manifest['name']        = esc_html__( 'Classic slider', 'seosight' );
$manifest['description'] = esc_html__( 'Classic Slider for Seosight theme', 'seosight' );
$manifest['version'] = '1.0.0';
$manifest['display'] = 'slider';
$manifest['standalone'] = true;
